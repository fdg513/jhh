﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ray.BiliBiliTool.DomainService.Interfaces
{
    /// <summary>
    /// 定义一个领域服务
    /// </summary>
    public interface IDomainService
    {
    }
}
