﻿namespace Ray.BiliBiliTool.Agent.BiliBiliAgent.Dtos
{
    public class VideoInfo
    {
        public long Id { get; set; }

        public string Bv_id { get; set; }

        public string Title { get; set; }
    }
}
