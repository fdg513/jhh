﻿using System.Collections.Generic;

namespace Ray.BiliBiliTool.Agent.BiliBiliAgent.Dtos
{
    public class GetVideosResponse
    {
        public List<VideoInfo> Media_list { get; set; }
    }
}
