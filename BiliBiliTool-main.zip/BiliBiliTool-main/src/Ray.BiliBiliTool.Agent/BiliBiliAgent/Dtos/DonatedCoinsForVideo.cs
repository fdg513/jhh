﻿namespace Ray.BiliBiliTool.Agent.BiliBiliAgent.Dtos
{
    public class DonatedCoinsForVideo
    {
        public int Multiply { get; set; }
    }
}
